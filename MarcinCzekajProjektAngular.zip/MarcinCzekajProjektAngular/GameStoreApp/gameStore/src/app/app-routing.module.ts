import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomersComponent } from './customers/customers.component';
import { GamesComponent } from './games/games.component';
import { GameStoreComponent } from './game-store/game-store.component';


const routes: Routes = [
    {
       path: 'customers',
       component: CustomersComponent
    },
    {
       path: 'games',
       component: GamesComponent
    },
    {
       path: 'game-store',
       component: GameStoreComponent
    }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-games',
  templateUrl: './games.component.html',
  styleUrls: ['./games.component.css']
})
export class GamesComponent implements OnInit {

  games;
  consoles;
  consoleName;
  name;
  consoleId;
  gameById;
  company;
  amount;
  price;
  Id;

  constructor(private httpClient : HttpClient) { }

  ngOnInit() {
    this.getAllGames();
    this.getAllConsoles();
  }


  getAllGames() : void
  {
  this.httpClient.get('http://localhost:8082/backend/games/select.php')
         .subscribe(games => this.games = games);
  }

  getGameById(id_game) : void
  {
  this.Id = id_game;
  console.log(this.Id);
  this.httpClient.get('http://localhost:8082/backend/games/selectGameById.php?id_customer=' + id_game).subscribe(gameById => this.gameById = gameById);
  }

  getAllConsoles() : void
  {
   this.httpClient.get('http://localhost:8082/backend/games/selectConsole.php')
         .subscribe(consoles => this.consoles = consoles);
  }

  getConsoleById(id_console) : void
  {
  this.Id = id_console;
  console.log(this.Id);
  this.httpClient.get('http://localhost:8082/backend/games/selectConsoleById.php?id_customer=' + id_console).subscribe(consoleId => this.consoleId  = consoleId);
  }



  insertGame() : void
  {
  const formData = new FormData();
  formData.append('name', this.name);
  formData.append('price', this.price);
  formData.append('consoleId', this.consoleId);
  formData.append('amount', this.amount);
  this.httpClient.post('http://localhost:8082/backend/games/insert.php', formData)
      .subscribe(() => this.getAllGames());
  }

  insertConsole() : void
  {
  const formData = new FormData();
  formData.append('consoleName', this.consoleName);
  formData.append('company', this.company);
  this.httpClient.post('http://localhost:8082/backend/games/insertConsole.php', formData)
      .subscribe(() => this.getAllConsoles());
  }

  deleteGame(Id) : void
  {
  this.httpClient.get('http://localhost:8082/backend/games/delete.php?Id=' + Id)
      .subscribe(() => this.getAllGames());
  }

  deleteConsole(Id) : void
  {
  this.httpClient.get('http://localhost:8082/backend/games/deleteConsole.php?Id=' + Id)
      .subscribe(() => this.getAllConsoles());
  }

}

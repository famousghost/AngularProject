import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-game-store',
  templateUrl: './game-store.component.html',
  styleUrls: ['./game-store.component.css']
})
export class GameStoreComponent implements OnInit {

  transactions;
  gamesToConsole;
  customers;
  gameToConsoleId;
  transactionId;
  userId;
  Id;

  constructor(private httpClient : HttpClient) { }

  ngOnInit() {
     this.getAllValues(); 
  }

  getAllValues() : void
  {
     this.getAllTransactions();
     this.getAllGamesWithConsoles();
     this.getAllCustomers();
  }

  getAllTransactions() : void
  {
  this.httpClient.get('http://localhost:8082/backend/gameStore/select.php')
         .subscribe(transactions => this.transactions = transactions);
  }

  getTransactionById(id_transaction) : void
  {
  this.Id = id_transaction;
  console.log(this.Id);
  this.httpClient.get('http://localhost:8082/backend/gameStore/selectTransactionById.php?Id=' + id_transaction).subscribe(transactionId => this.transactionId = transactionId);
  }

  getAllGamesWithConsoles() : void
  {
  this.httpClient.get('http://localhost:8082/backend/gameStore/selectGameToConsole.php')
         .subscribe(gamesToConsole => this.gamesToConsole = gamesToConsole);
  }

  getAllCustomers() : void
  {
  this.httpClient.get('http://localhost:8082/backend/gameStore/selectCustomers.php')
         .subscribe(customers => this.customers = customers);
  }

  insertTransaction() : void
  {
  const formData = new FormData();
  formData.append('userId', this.userId);
  formData.append('gameToConsoleId', this.gameToConsoleId);
  this.httpClient.post('http://localhost:8082/backend/gameStore/insert.php', formData)
      .subscribe(() => this.getAllValues());
  }

  deleteTransaction(id) : void
  {
  this.httpClient.get('http://localhost:8082/backend/gameStore/delete.php?Id=' + id)
      .subscribe(() => this.getAllValues());
  }

}

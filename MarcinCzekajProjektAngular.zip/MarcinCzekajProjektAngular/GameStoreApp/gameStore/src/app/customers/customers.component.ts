import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {

  customers;
  customerById;
  name;
  age;
  Id;

  constructor(private httpClient: HttpClient) { }

  ngOnInit() {
     this.getAllCustomers();
  }

  getAllCustomers() : void
  {
  this.httpClient.get('http://localhost:8082/backend/customers/select.php')
         .subscribe(customers => this.customers = customers);
  }

  getCustomersById(id_customer) : void
  {
  this.Id = id_customer;
  console.log(this.Id);
  this.httpClient.get('http://localhost:8082/backend/customers/selectById.php?id_customer=' + id_customer).subscribe(customerById => this.customerById = customerById);
  }

  insertCustomer() : void
  {
  const formData = new FormData();
  formData.append('name', this.name);
  formData.append('age', this.age);
  this.httpClient.post('http://localhost:8082/backend/customers/insert.php', formData)
      .subscribe(() => this.getAllCustomers());
  }

  deleteCustomer(Id) : void
  {
  this.httpClient.get('http://localhost:8082/backend/customers/delete.php?Id=' + Id)
      .subscribe(() => this.getAllCustomers());
  }

}

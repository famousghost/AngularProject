<?php
require_once('../connect.php');

$query = $conn->prepare("SELECT GTC.Id, G.Name As 'GameName', C.Name As 'ConsoleName' FROM GameToConsole GTC
				JOIN Games G ON GTC.GameId = G.Id
                                JOIN Console C ON GTC.ConsoleId = C.Id");
$query->execute();
echo json_encode($query->fetchAll());
?>

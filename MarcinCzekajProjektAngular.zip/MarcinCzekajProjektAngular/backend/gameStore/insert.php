<?php
require_once('../connect.php');

$query = $conn->prepare('INSERT INTO UserTransactions(UserId, GameToConsoleId, Date) VALUES (:userId, :gameToConsoleId, Now())');

if($_POST['userId'] != ''
	and $_POST['gameToConsoleId'] != '')
{
	$query->execute([
    	'userId' => $_POST['userId'],
    	'gameToConsoleId' => $_POST['gameToConsoleId']
	]);
}

?>

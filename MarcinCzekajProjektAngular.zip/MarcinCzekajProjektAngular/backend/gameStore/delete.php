<?php

require_once("../connect.php");

$query = $conn->prepare("DELETE FROM UserTransactions WHERE Id = :Id");
$query->execute(["Id" => $_GET["Id"]])

?>

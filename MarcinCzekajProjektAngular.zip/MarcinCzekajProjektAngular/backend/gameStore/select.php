<?php
require_once('../connect.php');

$query = $conn->prepare("SELECT UST.Id, U.Name As 'UserName', U.Age, G.Name As 'GameName', G.Price, C.Name As 'ConsoleName', C.Company, UST.Date FROM UserTransactions UST
       JOIN GameToConsole GTC ON UST.GameToConsoleId = GTC.Id
       JOIN Users U ON UST.UserId = U.Id
       JOIN Games G ON GTC.GameId = G.Id
       JOIN Console C ON GTC.ConsoleId = C.Id
       ");
$query->execute();
echo json_encode($query->fetchAll());
?>

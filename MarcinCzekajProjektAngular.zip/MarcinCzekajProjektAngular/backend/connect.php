<?php
//Database connection 
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: PUT, GET, POST');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');
header('Content-Type: application/json'); 

$hostname = 'localhost';
$database = 'phpmyadmin';
$username = 'phpmyadmin';
$password = 'Haslo123$';

$conn = new PDO('mysql:host=' . $hostname . ';dbname=' . $database, $username, $password);

?>

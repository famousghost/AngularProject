<?php
require_once('../connect.php');

$query = $conn->prepare("INSERT INTO Games(Name, Price) VALUES(:name, :price)");

if($_POST["consoleId"] >= 1 
	and $_POST["name"] != ""
        and $_POST["price"] != ""
        and $_POST["amount"] != "")
{
	$query->execute([
    	"name" => $_POST["name"],
    	"price" => $_POST["price"]
	]);
}
else
	echo "nope";

$query2 = $conn->prepare("INSERT INTO GameToConsole(GameId, ConsoleId, Amount) VALUES((SELECT Max(Id) FROM Games), :consoleId, :amount)");

if($_POST["consoleId"] >= 1 
	and $_POST["name"] != ""
        and $_POST["price"] != ""
        and $_POST["amount"] != "")
{	
	$query2->execute([
    	"consoleId" => $_POST["consoleId"],
    	"amount" => $_POST["amount"]
	]);
}

?>

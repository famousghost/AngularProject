<?php
require_once('../connect.php');

$query = $conn->prepare("INSERT INTO Console(Name, Company) VALUES(:consoleName, :company)");

$query->execute([
    "consoleName" => $_POST["consoleName"],
    "company" => $_POST["company"]
]);
?>

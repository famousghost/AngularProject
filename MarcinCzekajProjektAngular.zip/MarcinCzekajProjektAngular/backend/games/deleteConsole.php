<?php

require_once("../connect.php");

$query = $conn->prepare("DELETE FROM Console WHERE Id = :Id;
                         DELETE FROM UserTransactions WHERE GameToConsoleId = (SELECT Id FROM ConsoleId WHERE Id = :Id);
                         DELETE FROM GameToConsole WHERE ConsoleId = :Id");
$query->execute(["Id" => $_GET["Id"]])

?>

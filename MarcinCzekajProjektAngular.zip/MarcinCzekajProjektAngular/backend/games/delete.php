<?php

require_once("../connect.php");

$query = $conn->prepare("DELETE FROM Games WHERE Id = :Id;
                         DELETE FROM UserTransactions WHERE GameToConsoleId = (SELECT Id FROM GameToConsole WHERE GameId = :Id);
                         DELETE FROM GameToConsole WHERE GameId = :Id;
");
$query->execute(["Id" => $_GET["Id"]])

?>

<?php
require_once('../connect.php');

$query = $conn->prepare("SELECT G.Id, G.Name As 'GameName', G.Price As 'Price', C.Name As 'ConsoleName', GTC.Amount FROM GameToConsole GTC
			 JOIN Games G ON GTC.GameId = G.Id
                         JOIN Console C ON GTC.ConsoleId = C.Id");

$query->execute();
echo json_encode($query->fetchAll());
?>

<?php
require_once('../connect.php');

$query = $conn->prepare("SELECT Id, Name, Company FROM Console");

$query->execute();
echo json_encode($query->fetchAll());
?>

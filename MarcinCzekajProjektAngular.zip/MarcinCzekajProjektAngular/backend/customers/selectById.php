<?php
require_once('../connect.php');

$query = $conn->prepare("SELECT * FROM Users WHERE Id = :Id");
$query->execute(["Id" => $_GET["Id"]]);
echo json_encode($query->fetchAll());
?>

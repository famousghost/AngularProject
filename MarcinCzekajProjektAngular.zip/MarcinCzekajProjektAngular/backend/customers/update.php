<?php

require_once('../connect.php');

$query = $conn->prepare("UPDATE Users WHERE Id = :Id");
$query2 = $conn->prepare("DELETE FROM UserTransactions WHERE UserId = :Id;");

$query->execute(["Id" => $_GET["Id"]])
$query2->execute(["Id" => $_GET["Id"]]) 

?>

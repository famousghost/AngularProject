<?php

require_once("../connect.php");

$query = $conn->prepare("DELETE FROM Users WHERE Id = :Id;
                         DELETE FROM UserTransactions WHERE UserId = :Id");
$query->execute(["Id" => $_GET["Id"]])

?>

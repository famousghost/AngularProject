<?php
require_once('../connect.php');

$query = $conn->prepare("INSERT INTO Users(Name, Age) VALUES(:name, :age)");

if($_POST["name"] != ''
	and $_POST['age'] != '')
{
	$query->execute([
    	"name" => $_POST["name"],
    	"age" => $_POST["age"]
	]);
}

?>
